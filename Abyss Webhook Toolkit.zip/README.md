Hi there! thanks for using Abyss Webhook Toolkit if you have any ideas for the next update
let me know at my discord kai78ish#7668